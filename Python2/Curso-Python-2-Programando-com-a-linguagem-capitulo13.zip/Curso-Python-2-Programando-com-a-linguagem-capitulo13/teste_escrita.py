arquivo = open('teste.txt', 'w')
arquivo.write('Python rocks \n')
print arquivo.mode
arquivo.close()