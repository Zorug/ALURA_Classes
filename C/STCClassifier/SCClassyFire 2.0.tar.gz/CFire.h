#define TAMANHO_STRING_CSV 180
#define QNT_LINHAS_CSV 8000
#define COLUNAS_MATRIZ 16
#define STRING_MATRIZ 45

void importa_do_arquivo();
void organiza_matriz_string();
void interface();
void troca_letra_por_numero();
void transforma_string_em_float();
void ordena_coluna();
void imprime_coluna();
void filtra_coluna();
